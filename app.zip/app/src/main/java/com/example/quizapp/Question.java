package com.example.quizapp;

public class Question {
    String text;
    boolean answer;

    public Question(String question, boolean ans) {
        text = question;
        answer = ans;
    }
}